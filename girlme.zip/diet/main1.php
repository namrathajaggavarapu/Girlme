<html>
<head>
     <title>Girl Me</title>
     <link rel="stylesheet" type="text/css" href="mainstyle.css">
     <link href='https://fonts.googleapis.com/css?family=Cedarville Cursive' rel='stylesheet'>
 
</head>
<body>
    <header>
    <div class="main">
            <ul>
                <li><a href="education.php">Education</a></li>
                <li><a href="health.php">Health</a></li>
                <li><a href="safety.php">Safety</a></li>
                <li><a href="employ.php">Women Employment</a></li>
                <li><a href="rights.php">Rights</a></li>

            </ul>
        </div>
       <!-- <div class="content">
           <h1>Girl Me</h1>
           <p>I am proud of myself....</p>
           
           <!-<button onclick="login()" id="asd">LOGIN</button> -->
        </div> 
        <div class="content" style="font-family: Arial">
            <h1 class="content12">Girl Me</h1>
            <p class="content12" style="font-size: 40px">I am proud of myself....</p>
        </div>
    </header>
</body>